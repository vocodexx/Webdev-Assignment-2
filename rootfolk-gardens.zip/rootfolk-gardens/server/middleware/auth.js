import jwt from 'jsonwebtoken';
import { read } from '../utils/store.js';

const secret = process.env.JWT_SECRET || 'rootfolk-development-secret-change-me';

// Create a short JWT containing only the user's id and role.
export function signUser(user) {
  return jwt.sign({ id: user.id, role: user.role }, secret, { expiresIn: '7d' });
}

// Protect API routes by checking the Bearer token sent by the React app.
export function requireAuth(req, res, next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ message: 'Please log in to continue.' });

  try {
    const decoded = jwt.verify(token, secret);
    const user = read('users').find((item) => item.id === decoded.id);
    if (!user) return res.status(401).json({ message: 'Account no longer exists.' });

    // Store the current user on the request for later route handlers.
    req.user = user;
    next();
  } catch {
    res.status(401).json({ message: 'Your session has expired. Please log in again.' });
  }
}

// Extra middleware used by admin-only routes.
export function requireAdmin(req, res, next) {
  if (req.user?.role !== 'admin') return res.status(403).json({ message: 'Admin access required.' });
  next();
}

// Never send password hashes back to the browser.
export function publicUser(user) {
  const { passwordHash, ...safe } = user;
  return safe;
}
