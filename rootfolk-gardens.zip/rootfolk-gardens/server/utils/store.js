import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(__dirname, '..', 'data');

// Create a JSON data file the first time it is requested.
export function ensureFile(name, fallback = []) {
  fs.mkdirSync(dataDir, { recursive: true });
  const file = path.join(dataDir, `${name}.json`);
  if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(fallback, null, 2));
  return file;
}

// Read a JSON collection and return a safe fallback if parsing fails.
export function read(name, fallback = []) {
  const file = ensureFile(name, fallback);
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

// Write the full collection back to its JSON file.
export function write(name, value) {
  const file = ensureFile(name, value);
  fs.writeFileSync(file, JSON.stringify(value, null, 2));
  return value;
}

// Utility for simple read -> change -> write operations.
export function update(name, updater, fallback = []) {
  const current = read(name, fallback);
  const next = updater(current);
  write(name, next);
  return next;
}
