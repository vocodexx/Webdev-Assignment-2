import bcrypt from 'bcryptjs';
import { randomUUID } from 'node:crypto';
import { read, write } from './store.js';

// Add demo accounts and example activity only when the data store is empty.
export async function seedDemoData() {
  const users = read('users');
  if (users.length) return;

  const adminId = randomUUID();
  const customerId = randomUUID();
  const gardenId = randomUUID();
  const quoteId = randomUUID();
  const bookingId = randomUUID();
  const visitId = randomUUID();

  // Demo users allow both sides of the application to be tested immediately.
  write('users', [
    {
      id: adminId,
      role: 'admin',
      name: 'Rootfolk Admin',
      email: 'admin@rootfolk.test',
      phone: '07960 430982',
      address: 'Rootfolk Gardens, Surrey',
      postcode: 'GU1 1AA',
      passwordHash: await bcrypt.hash('RootfolkAdmin1!', 10),
      createdAt: new Date().toISOString()
    },
    {
      id: customerId,
      role: 'customer',
      name: 'Alex Morgan',
      email: 'customer@rootfolk.test',
      phone: '07700 900123',
      address: '12 Meadow Lane, Surrey',
      postcode: 'GU24 8AA',
      passwordHash: await bcrypt.hash('Garden123!', 10),
      createdAt: new Date().toISOString()
    }
  ]);

  // Give the demo customer a basic garden profile.
  write('gardens', [{
    id: gardenId,
    userId: customerId,
    propertyType: 'Detached',
    size: 'Medium',
    access: 'Side access',
    condition: 'Generally maintained',
    lawn: true,
    hedges: true,
    borders: true,
    trees: false,
    wasteRemoval: true,
    notes: 'Rear garden with lawn, mixed borders and a long boundary hedge.',
    images: []
  }]);

  write('quoteRequests', []);
  // Seed one accepted quote, upcoming booking and previous visit for the dashboard.
  write('quotes', [{
    id: quoteId,
    userId: customerId,
    gardenId,
    serviceNames: ['Regular garden maintenance'],
    description: 'Fortnightly maintenance for lawn, borders and hedge checks.',
    amount: 85,
    durationHours: 2,
    status: 'accepted',
    validUntil: '2026-12-31',
    createdAt: new Date().toISOString()
  }]);

  const futureDate = new Date();
  futureDate.setDate(futureDate.getDate() + 7);
  write('bookings', [{
    id: bookingId,
    userId: customerId,
    quoteId,
    date: futureDate.toISOString().slice(0, 10),
    startTime: '09:00',
    endTime: '11:00',
    status: 'confirmed',
    serviceNames: ['Regular garden maintenance'],
    amount: 85,
    createdAt: new Date().toISOString()
  }]);

  const pastDate = new Date();
  pastDate.setDate(pastDate.getDate() - 14);
  write('visits', [{
    id: visitId,
    userId: customerId,
    bookingId: null,
    date: pastDate.toISOString().slice(0, 10),
    serviceNames: ['Regular garden maintenance'],
    tasks: ['Lawn mowed and edged', 'Front hedge trimmed', 'Borders weeded', 'Paths swept'],
    notes: 'Lawn is responding well. Rear hedge may need a stronger prune next visit.',
    amount: 85
  }]);

  write('changeRequests', []);
}
