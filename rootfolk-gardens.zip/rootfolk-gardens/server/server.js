import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import bcrypt from 'bcryptjs';
import multer from 'multer';
import { read, write } from './utils/store.js';
import { seedDemoData } from './utils/seed.js';
import { publicUser, requireAdmin, requireAuth, signUser } from './middleware/auth.js';

// Basic server configuration and upload directory.
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 4000;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:5173';
const uploadsDir = path.join(__dirname, 'uploads');
fs.mkdirSync(uploadsDir, { recursive: true });

// Create demo content on first run so the main workflows can be tested.
await seedDemoData();

// Shared Express middleware used by every API route.
app.use(cors({ origin: CLIENT_ORIGIN }));
app.use(express.json({ limit: '2mb' }));
app.use('/uploads', express.static(uploadsDir));

// Multer stores customer garden photos and rejects unsupported file types.
const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, `${Date.now()}-${randomUUID()}${ext}`);
    }
  }),
  limits: { fileSize: 6 * 1024 * 1024, files: 6 },
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    cb(allowed.includes(file.mimetype) ? null : new Error('Only JPG, PNG and WebP images are allowed.'), allowed.includes(file.mimetype));
  }
});

// Services are kept here because they are small, fixed reference data.
const services = [
  { id: 'maintenance', name: 'Regular garden maintenance', description: 'Routine mowing, edging, weeding, deadheading and general care.' },
  { id: 'hedges', name: 'Hedge cutting & pruning', description: 'Careful shaping and pruning for healthy, tidy growth.' },
  { id: 'tidy', name: 'Garden tidy-up', description: 'One-off help to bring a garden back under control.' },
  { id: 'clearance', name: 'Garden clearance', description: 'Removal of unwanted vegetation and green waste.' },
  { id: 'lawn', name: 'Lawn care', description: 'Mowing, edging and seasonal lawn maintenance.' },
  { id: 'planting', name: 'Planting & border care', description: 'Border refreshes, planting and ongoing care.' },
  { id: 'seasonal', name: 'Seasonal garden care', description: 'Spring preparation, autumn clearance and winter-ready visits.' }
];

const slotTemplates = [
  ['08:00', '10:00'],
  ['10:30', '12:30'],
  ['13:30', '15:30']
];

// Small helper functions keep repeated ownership checks out of route handlers.
function getUserGarden(userId) {
  return read('gardens').find((g) => g.userId === userId) || null;
}

function ownOrAdmin(resource, user) {
  return resource && (resource.userId === user.id || user.role === 'admin');
}

// ---------- Public API ----------
app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.get('/api/services', (_req, res) => res.json(services));

// ---------- Authentication ----------
app.post('/api/auth/register', async (req, res) => {
  const { name, email, phone, password, address, postcode } = req.body;
  if (!name || !email || !password || !postcode) return res.status(400).json({ message: 'Name, email, password and postcode are required.' });
  if (password.length < 8) return res.status(400).json({ message: 'Password must be at least 8 characters.' });
  const users = read('users');
  if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) return res.status(409).json({ message: 'An account already exists for this email.' });
  // Passwords are hashed before the user record is stored.
  const user = {
    id: randomUUID(), role: 'customer', name: name.trim(), email: email.trim().toLowerCase(), phone: phone?.trim() || '',
    address: address?.trim() || '', postcode: postcode.trim().toUpperCase(), passwordHash: await bcrypt.hash(password, 10), createdAt: new Date().toISOString()
  };
  write('users', [...users, user]);
  const garden = { id: randomUUID(), userId: user.id, propertyType: '', size: '', access: '', condition: '', lawn: false, hedges: false, borders: false, trees: false, wasteRemoval: false, notes: '', images: [] };
  write('gardens', [...read('gardens'), garden]);
  res.status(201).json({ token: signUser(user), user: publicUser(user) });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const user = read('users').find((u) => u.email.toLowerCase() === String(email || '').toLowerCase());
  if (!user || !(await bcrypt.compare(password || '', user.passwordHash))) return res.status(401).json({ message: 'Incorrect email or password.' });
  res.json({ token: signUser(user), user: publicUser(user) });
});

app.get('/api/auth/me', requireAuth, (req, res) => res.json(publicUser(req.user)));

// ---------- Garden profile and photo uploads ----------
app.get('/api/garden', requireAuth, (req, res) => res.json(getUserGarden(req.user.id)));
app.put('/api/garden', requireAuth, (req, res) => {
  const gardens = read('gardens');
  const index = gardens.findIndex((g) => g.userId === req.user.id);
  if (index < 0) return res.status(404).json({ message: 'Garden profile not found.' });
  const current = gardens[index];
  const allowed = ['propertyType', 'size', 'access', 'condition', 'lawn', 'hedges', 'borders', 'trees', 'wasteRemoval', 'notes'];
  const next = { ...current };
  allowed.forEach((key) => { if (key in req.body) next[key] = req.body[key]; });
  gardens[index] = next;
  write('gardens', gardens);
  res.json(next);
});

app.post('/api/garden/images', requireAuth, upload.array('images', 6), (req, res) => {
  const gardens = read('gardens');
  const index = gardens.findIndex((g) => g.userId === req.user.id);
  if (index < 0) return res.status(404).json({ message: 'Garden profile not found.' });
  const additions = (req.files || []).map((file) => ({ id: randomUUID(), url: `/uploads/${file.filename}`, originalName: file.originalname, uploadedAt: new Date().toISOString() }));
  gardens[index].images = [...(gardens[index].images || []), ...additions];
  write('gardens', gardens);
  res.status(201).json(gardens[index]);
});

app.delete('/api/garden/images/:imageId', requireAuth, (req, res) => {
  const gardens = read('gardens');
  const index = gardens.findIndex((g) => g.userId === req.user.id);
  if (index < 0) return res.status(404).json({ message: 'Garden profile not found.' });
  const image = gardens[index].images.find((img) => img.id === req.params.imageId);
  gardens[index].images = gardens[index].images.filter((img) => img.id !== req.params.imageId);
  write('gardens', gardens);
  if (image?.url?.startsWith('/uploads/')) {
    const filePath = path.join(uploadsDir, path.basename(image.url));
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  }
  res.status(204).end();
});

// ---------- Quote workflow ----------
app.post('/api/quote-requests', requireAuth, (req, res) => {
  const garden = getUserGarden(req.user.id);
  if (!garden) return res.status(400).json({ message: 'Complete your garden profile first.' });
  const { serviceIds = [], description = '', frequency = 'One-off', imageIds = [] } = req.body;
  if (!serviceIds.length) return res.status(400).json({ message: 'Choose at least one service.' });
  if (imageIds.length < 2) return res.status(400).json({ message: 'Please attach at least two garden photos so Rootfolk can assess the job.' });
  // Check selected image IDs belong to this customer's garden, not another account.
  const validImages = (garden.images || []).filter((img) => imageIds.includes(img.id));
  if (validImages.length < 2) return res.status(400).json({ message: 'Two valid garden photos are required.' });
  const request = {
    id: randomUUID(), userId: req.user.id, gardenId: garden.id,
    serviceIds, serviceNames: services.filter((s) => serviceIds.includes(s.id)).map((s) => s.name),
    description, frequency, imageIds, status: 'under-review', createdAt: new Date().toISOString()
  };
  write('quoteRequests', [...read('quoteRequests'), request]);
  res.status(201).json(request);
});

app.get('/api/quote-requests', requireAuth, (req, res) => {
  res.json(read('quoteRequests').filter((q) => q.userId === req.user.id));
});

app.get('/api/quotes', requireAuth, (req, res) => {
  const quotes = read('quotes').filter((q) => q.userId === req.user.id);
  res.json(quotes);
});

app.post('/api/quotes/:id/accept', requireAuth, (req, res) => {
  const quotes = read('quotes');
  const index = quotes.findIndex((q) => q.id === req.params.id);
  if (index < 0 || !ownOrAdmin(quotes[index], req.user)) return res.status(404).json({ message: 'Quote not found.' });
  quotes[index].status = 'accepted';
  write('quotes', quotes);
  res.json(quotes[index]);
});

app.post('/api/quotes/:id/decline', requireAuth, (req, res) => {
  const quotes = read('quotes');
  const index = quotes.findIndex((q) => q.id === req.params.id);
  if (index < 0 || !ownOrAdmin(quotes[index], req.user)) return res.status(404).json({ message: 'Quote not found.' });
  quotes[index].status = 'declined';
  write('quotes', quotes);
  res.json(quotes[index]);
});

// ---------- Availability and bookings ----------
app.get('/api/availability', requireAuth, (req, res) => {
  const start = req.query.from ? new Date(`${req.query.from}T12:00:00`) : new Date();
  const days = Math.min(Math.max(Number(req.query.days) || 14, 1), 31);
  const bookings = read('bookings').filter((b) => !['cancelled'].includes(b.status));
  const result = [];
  for (let i = 0; i < days; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    const weekday = d.getDay();
    if (weekday === 0 || weekday === 6) continue;
    const date = d.toISOString().slice(0, 10);
    // A slot is available only when no active booking uses the same date/time.
    const slots = slotTemplates.map(([startTime, endTime]) => ({
      startTime, endTime,
      available: !bookings.some((b) => b.date === date && b.startTime === startTime && b.status !== 'cancelled')
    }));
    result.push({ date, slots });
  }
  res.json(result);
});

app.post('/api/bookings', requireAuth, (req, res) => {
  const { quoteId, date, startTime, endTime } = req.body;
  const quotes = read('quotes');
  const quote = quotes.find((q) => q.id === quoteId && q.userId === req.user.id && q.status === 'accepted');
  if (!quote) return res.status(400).json({ message: 'Accept a valid quote before booking.' });
  const collision = read('bookings').some((b) => b.date === date && b.startTime === startTime && b.status !== 'cancelled');
  if (collision) return res.status(409).json({ message: 'That appointment has just been taken. Please choose another.' });
  const booking = {
    id: randomUUID(), userId: req.user.id, quoteId, date, startTime, endTime,
    status: 'confirmed', serviceNames: quote.serviceNames, amount: quote.amount, createdAt: new Date().toISOString()
  };
  write('bookings', [...read('bookings'), booking]);
  res.status(201).json(booking);
});

app.get('/api/bookings', requireAuth, (req, res) => {
  res.json(read('bookings').filter((b) => b.userId === req.user.id).sort((a, b) => `${a.date}${a.startTime}`.localeCompare(`${b.date}${b.startTime}`)));
});

// Booking changes are requests first, so the existing appointment stays valid until approval.
app.post('/api/bookings/:id/reschedule-request', requireAuth, (req, res) => {
  const booking = read('bookings').find((b) => b.id === req.params.id && b.userId === req.user.id);
  if (!booking) return res.status(404).json({ message: 'Booking not found.' });
  const request = { id: randomUUID(), bookingId: booking.id, userId: req.user.id, type: 'reschedule', requestedDate: req.body.requestedDate || '', requestedTime: req.body.requestedTime || '', reason: req.body.reason || '', status: 'pending', createdAt: new Date().toISOString() };
  write('changeRequests', [...read('changeRequests'), request]);
  const bookings = read('bookings').map((b) => b.id === booking.id ? { ...b, status: 'reschedule-requested' } : b);
  write('bookings', bookings);
  res.status(201).json(request);
});

app.post('/api/bookings/:id/cancellation-request', requireAuth, (req, res) => {
  const booking = read('bookings').find((b) => b.id === req.params.id && b.userId === req.user.id);
  if (!booking) return res.status(404).json({ message: 'Booking not found.' });
  const request = { id: randomUUID(), bookingId: booking.id, userId: req.user.id, type: 'cancellation', reason: req.body.reason || '', status: 'pending', createdAt: new Date().toISOString() };
  write('changeRequests', [...read('changeRequests'), request]);
  const bookings = read('bookings').map((b) => b.id === booking.id ? { ...b, status: 'cancellation-requested' } : b);
  write('bookings', bookings);
  res.status(201).json(request);
});

// ---------- Completed visit history ----------
app.get('/api/visits', requireAuth, (req, res) => {
  res.json(read('visits').filter((v) => v.userId === req.user.id).sort((a, b) => b.date.localeCompare(a.date)));
});

// ---------- Admin API ----------
app.get('/api/admin/overview', requireAuth, requireAdmin, (_req, res) => {
  const quoteRequests = read('quoteRequests');
  const bookings = read('bookings');
  const changes = read('changeRequests');
  res.json({
    pendingQuotes: quoteRequests.filter((q) => q.status === 'under-review').length,
    upcomingJobs: bookings.filter((b) => ['confirmed', 'reschedule-requested', 'cancellation-requested'].includes(b.status)).length,
    changeRequests: changes.filter((c) => c.status === 'pending').length,
    customers: read('users').filter((u) => u.role === 'customer').length
  });
});

app.get('/api/admin/quote-requests', requireAuth, requireAdmin, (_req, res) => {
  const users = read('users');
  const gardens = read('gardens');
  const rows = read('quoteRequests').map((q) => ({
    ...q,
    customer: publicUser(users.find((u) => u.id === q.userId) || {}),
    garden: gardens.find((g) => g.id === q.gardenId) || null
  }));
  res.json(rows);
});

app.post('/api/admin/quote-requests/:id/quote', requireAuth, requireAdmin, (req, res) => {
  const requests = read('quoteRequests');
  const index = requests.findIndex((q) => q.id === req.params.id);
  if (index < 0) return res.status(404).json({ message: 'Quote request not found.' });
  const amount = Number(req.body.amount);
  const durationHours = Number(req.body.durationHours);
  if (!Number.isFinite(amount) || amount <= 0) return res.status(400).json({ message: 'Enter a valid quote amount.' });
  const quote = {
    id: randomUUID(), userId: requests[index].userId, gardenId: requests[index].gardenId,
    quoteRequestId: requests[index].id, serviceNames: requests[index].serviceNames,
    description: req.body.notes || requests[index].description, amount,
    durationHours: Number.isFinite(durationHours) && durationHours > 0 ? durationHours : 2,
    status: 'ready', validUntil: req.body.validUntil || '', createdAt: new Date().toISOString()
  };
  requests[index].status = 'quote-ready';
  write('quoteRequests', requests);
  write('quotes', [...read('quotes'), quote]);
  res.status(201).json(quote);
});

app.get('/api/admin/change-requests', requireAuth, requireAdmin, (_req, res) => {
  const bookings = read('bookings');
  const users = read('users');
  res.json(read('changeRequests').map((r) => ({
    ...r,
    booking: bookings.find((b) => b.id === r.bookingId),
    customer: publicUser(users.find((u) => u.id === r.userId) || {})
  })));
});

// Approving a request updates the booking; declining restores its confirmed state.
app.patch('/api/admin/change-requests/:id', requireAuth, requireAdmin, (req, res) => {
  const changes = read('changeRequests');
  const index = changes.findIndex((r) => r.id === req.params.id);
  if (index < 0) return res.status(404).json({ message: 'Change request not found.' });
  const action = req.body.action;
  if (!['approve', 'decline'].includes(action)) return res.status(400).json({ message: 'Action must be approve or decline.' });
  changes[index].status = action === 'approve' ? 'approved' : 'declined';
  changes[index].resolvedAt = new Date().toISOString();
  write('changeRequests', changes);
  const bookings = read('bookings');
  const bIndex = bookings.findIndex((b) => b.id === changes[index].bookingId);
  if (bIndex >= 0) {
    if (action === 'approve' && changes[index].type === 'cancellation') bookings[bIndex].status = 'cancelled';
    else if (action === 'approve' && changes[index].type === 'reschedule') {
      if (changes[index].requestedDate) bookings[bIndex].date = changes[index].requestedDate;
      if (changes[index].requestedTime) {
        bookings[bIndex].startTime = changes[index].requestedTime;
        const [h, m] = changes[index].requestedTime.split(':').map(Number);
        bookings[bIndex].endTime = `${String(h + 2).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
      }
      bookings[bIndex].status = 'confirmed';
    } else if (action === 'decline') bookings[bIndex].status = 'confirmed';
    write('bookings', bookings);
  }
  res.json(changes[index]);
});

app.post('/api/admin/bookings/:id/complete', requireAuth, requireAdmin, (req, res) => {
  const bookings = read('bookings');
  const index = bookings.findIndex((b) => b.id === req.params.id);
  if (index < 0) return res.status(404).json({ message: 'Booking not found.' });
  bookings[index].status = 'completed';
  write('bookings', bookings);
  const visit = {
    id: randomUUID(), userId: bookings[index].userId, bookingId: bookings[index].id, date: bookings[index].date,
    serviceNames: bookings[index].serviceNames, tasks: Array.isArray(req.body.tasks) ? req.body.tasks : [], notes: req.body.notes || '', amount: bookings[index].amount
  };
  write('visits', [...read('visits'), visit]);
  res.status(201).json(visit);
});

// Final error handler converts upload/server errors into readable JSON responses.
app.use((err, _req, res, _next) => {
  console.error(err);
  if (err instanceof multer.MulterError) return res.status(400).json({ message: err.message });
  res.status(400).json({ message: err.message || 'Something went wrong.' });
});

app.listen(PORT, () => console.log(`Rootfolk API running on http://localhost:${PORT}`));
