import { Route, Routes } from 'react-router-dom';
import Home from './pages/Home.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Garden from './pages/Garden.jsx';
import QuoteRequest from './pages/QuoteRequest.jsx';
import Quotes from './pages/Quotes.jsx';
import Bookings from './pages/Bookings.jsx';
import History from './pages/History.jsx';
import Admin from './pages/Admin.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import PortalLayout from './components/PortalLayout.jsx';

export default function App() {
  return (
    <Routes>
      {/* Public pages can be opened without signing in. */}
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {/* Customer pages are grouped inside one protected portal layout. */}
      <Route element={<ProtectedRoute><PortalLayout /></ProtectedRoute>}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/garden" element={<Garden />} />
        <Route path="/quote-request" element={<QuoteRequest />} />
        <Route path="/quotes" element={<Quotes />} />
        <Route path="/bookings" element={<Bookings />} />
        <Route path="/history" element={<History />} />
      </Route>

      {/* Only an authenticated admin can open the admin dashboard. */}
      <Route path="/admin" element={<ProtectedRoute admin><Admin /></ProtectedRoute>} />
    </Routes>
  );
}
