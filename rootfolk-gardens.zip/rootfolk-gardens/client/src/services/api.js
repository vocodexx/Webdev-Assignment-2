const API = '/api';

// Small helper used by every page to call the Express API consistently.
export async function api(path, options = {}) {
  const token = localStorage.getItem('rootfolk_token');
  const headers = { ...(options.headers || {}) };

  // FormData sets its own content type, normal JSON requests do not.
  if (!(options.body instanceof FormData)) headers['Content-Type'] = 'application/json';

  // Send the login token when the customer is signed in.
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${API}${path}`, { ...options, headers });
  if (res.status === 204) return null;

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || 'Request failed');

  return data;
}
