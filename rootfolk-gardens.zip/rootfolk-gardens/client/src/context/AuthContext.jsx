import { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../services/api.js';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Restore a previous login when the browser is refreshed.
  useEffect(() => {
    const token = localStorage.getItem('rootfolk_token');
    if (!token) return setLoading(false);

    api('/auth/me')
      .then(setUser)
      .catch(() => localStorage.removeItem('rootfolk_token'))
      .finally(() => setLoading(false));
  }, []);

  // Log in through the API, then store the token for later requests.
  async function login(email, password) {
    const data = await api('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
    localStorage.setItem('rootfolk_token', data.token);
    setUser(data.user);
    return data.user;
  }

  // Registration also signs the new customer in immediately.
  async function register(payload) {
    const data = await api('/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    localStorage.setItem('rootfolk_token', data.token);
    setUser(data.user);
    return data.user;
  }

  function logout() {
    localStorage.removeItem('rootfolk_token');
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
