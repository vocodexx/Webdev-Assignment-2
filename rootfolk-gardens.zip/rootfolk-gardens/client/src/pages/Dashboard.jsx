import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../services/api.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Dashboard() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [visits, setVisits] = useState([]);
  const [quotes, setQuotes] = useState([]);

  // Load the main account information together so the dashboard opens quickly.
  useEffect(() => {
    Promise.all([api('/bookings'), api('/visits'), api('/quotes')])
      .then(([bookingData, visitData, quoteData]) => {
        setBookings(bookingData);
        setVisits(visitData);
        setQuotes(quoteData);
      });
  }, []);

  // Pick the most useful records to show in the summary cards.
  const next = bookings.find((booking) =>
    ['confirmed', 'reschedule-requested', 'cancellation-requested'].includes(booking.status)
  );
  const last = visits[0];
  const ready = quotes.find((quote) => quote.status === 'ready');

  return (
    <section>
      <p className="eyebrow">Overview</p>
      <h1>Welcome back, {user?.name?.split(' ')[0]}.</h1>
      <p className="muted">Everything about your garden care, in one place.</p>

      <div className="dashboard-grid">
        <article className="metric-card highlight">
          <span>Next visit</span>
          <h3>{next ? new Date(`${next.date}T12:00`).toLocaleDateString('en-GB', { day: 'numeric', month: 'long' }) : 'Nothing booked'}</h3>
          {next && <><p>{next.startTime}–{next.endTime}</p><p>{next.serviceNames?.join(', ')}</p></>}
          <Link to="/bookings">View bookings →</Link>
        </article>

        <article className="metric-card">
          <span>Last visit</span>
          <h3>{last ? new Date(`${last.date}T12:00`).toLocaleDateString('en-GB', { day: 'numeric', month: 'long' }) : 'No visits yet'}</h3>
          {last && <p>{last.serviceNames.join(', ')}</p>}
          <Link to="/history">Visit history →</Link>
        </article>

        <article className="metric-card">
          <span>Quote status</span>
          <h3>{ready ? 'Quote ready' : quotes.length ? 'Up to date' : 'No active quote'}</h3>
          {ready && <p>£{Number(ready.amount).toFixed(2)}</p>}
          <Link to="/quotes">View quotes →</Link>
        </article>
      </div>

      <div className="panel">
        <h2>Quick actions</h2>
        <div className="actions">
          <Link className="btn" to="/quote-request">Request a quote</Link>
          <Link className="btn btn-ghost dark" to="/garden">Update garden photos</Link>
        </div>
      </div>
    </section>
  );
}
