import { useEffect, useState } from 'react';
import { api } from '../services/api.js';

export default function History() {
  const [visits, setVisits] = useState([]);

  // Completed visits are returned newest first by the API.
  useEffect(() => {
    api('/visits').then(setVisits);
  }, []);

  return (
    <section>
      <p className="eyebrow">Visit history</p>
      <h1>Previous garden visits</h1>

      <div className="stack">
        {visits.map((visit) => (
          <article className="panel" key={visit.id}>
            <span className="status completed">completed</span>
            <h2>{new Date(`${visit.date}T12:00`).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}</h2>
            <p><b>{visit.serviceNames.join(', ')}</b></p>

            {/* Show the checklist recorded for this completed visit. */}
            {visit.tasks?.length > 0 && (
              <ul className="task-list">
                {visit.tasks.map((task) => <li key={task}>✓ {task}</li>)}
              </ul>
            )}

            <p className="note">{visit.notes}</p>
            <p className="price-small">£{Number(visit.amount).toFixed(2)}</p>
          </article>
        ))}

        {!visits.length && <div className="panel"><p>No completed visits yet.</p></div>}
      </div>
    </section>
  );
}
