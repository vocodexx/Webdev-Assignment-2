import { useEffect, useState } from 'react';
import { api } from '../services/api.js';

const blank = {
  propertyType: '', size: '', access: '', condition: '',
  lawn: false, hedges: false, borders: false, trees: false,
  wasteRemoval: false, notes: '', images: []
};

export default function Garden() {
  const [garden, setGarden] = useState(blank);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  // Load the signed-in customer's saved garden profile.
  async function load() {
    try {
      setGarden(await api('/garden') || blank);
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => { load(); }, []);

  // Handles text, select and checkbox fields with one function.
  function change(e) {
    const { name, type, checked, value } = e.target;
    setGarden((current) => ({
      ...current,
      [name]: type === 'checkbox' ? checked : value
    }));
  }

  async function save(e) {
    e.preventDefault();
    setMsg('');
    setError('');
    try {
      const saved = await api('/garden', { method: 'PUT', body: JSON.stringify(garden) });
      setGarden(saved);
      setMsg('Garden profile saved.');
    } catch (err) {
      setError(err.message);
    }
  }

  // Upload selected images as FormData because they are real files, not JSON.
  async function upload(e) {
    const files = [...e.target.files];
    if (!files.length) return;

    const body = new FormData();
    files.forEach((file) => body.append('images', file));

    try {
      setGarden(await api('/garden/images', { method: 'POST', body }));
      setMsg('Photos uploaded.');
    } catch (err) {
      setError(err.message);
    }
    e.target.value = '';
  }

  async function remove(id) {
    await api(`/garden/images/${id}`, { method: 'DELETE' });
    load();
  }

  return (
    <section>
      <p className="eyebrow">My garden</p>
      <h1>Garden profile</h1>
      <p className="muted">These details help Rootfolk understand the space before preparing a quote.</p>
      {msg && <p className="success">{msg}</p>}
      {error && <p className="alert">{error}</p>}

      <form className="panel" onSubmit={save}>
        <div className="form-grid">
          <label>Property type
            <select name="propertyType" value={garden.propertyType} onChange={change}>
              <option value="">Select</option><option>Detached</option><option>Semi-detached</option><option>Terraced</option><option>Flat</option>
            </select>
          </label>
          <label>Garden size
            <select name="size" value={garden.size} onChange={change}>
              <option value="">Select</option><option>Small</option><option>Medium</option><option>Large</option><option>Very large</option>
            </select>
          </label>
          <label>Access
            <select name="access" value={garden.access} onChange={change}>
              <option value="">Select</option><option>Side access</option><option>Rear access</option><option>Through house</option><option>Other</option>
            </select>
          </label>
          <label>Condition
            <select name="condition" value={garden.condition} onChange={change}>
              <option value="">Select</option><option>Generally maintained</option><option>Needs attention</option><option>Overgrown</option><option>Starting from scratch</option>
            </select>
          </label>
        </div>

        <div className="checkbox-grid">
          <label><input type="checkbox" name="lawn" checked={garden.lawn} onChange={change} /> Lawn</label>
          <label><input type="checkbox" name="hedges" checked={garden.hedges} onChange={change} /> Hedges</label>
          <label><input type="checkbox" name="borders" checked={garden.borders} onChange={change} /> Borders</label>
          <label><input type="checkbox" name="trees" checked={garden.trees} onChange={change} /> Trees</label>
          <label><input type="checkbox" name="wasteRemoval" checked={garden.wasteRemoval} onChange={change} /> Waste removal needed</label>
        </div>

        <label>Notes<textarea name="notes" rows="4" value={garden.notes} onChange={change} /></label>
        <button className="btn">Save garden profile</button>
      </form>

      <div className="panel">
        <h2>Garden photos</h2>
        <p className="muted">Upload clear photos of the rear/front garden, lawn, hedges and any problem areas. At least two photos are required for a quote request.</p>
        <label className="upload-box">+ Add photos
          <input type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={upload} />
        </label>

        {/* Uploaded photos can be reviewed and removed before requesting a quote. */}
        <div className="photo-grid">
          {(garden.images || []).map((img) => (
            <figure key={img.id}>
              <img src={img.url} alt={img.originalName} />
              <figcaption>{img.originalName}<button onClick={() => remove(img.id)}>Remove</button></figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
