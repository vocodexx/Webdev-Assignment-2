import { useEffect, useState } from 'react';
import { api } from '../services/api.js';

export default function Quotes() {
  const [quotes, setQuotes] = useState([]);
  const [requests, setRequests] = useState([]);
  const [msg, setMsg] = useState('');

  // Load both submitted requests and completed quotations.
  async function load() {
    const [quoteData, requestData] = await Promise.all([api('/quotes'), api('/quote-requests')]);
    setQuotes(quoteData);
    setRequests(requestData);
  }

  useEffect(() => { load(); }, []);

  // Customers can accept or decline a prepared quote.
  async function action(id, type) {
    await api(`/quotes/${id}/${type}`, { method: 'POST' });
    setMsg(type === 'accept'
      ? 'Quote accepted. You can now book an available visit.'
      : 'Quote declined.');
    load();
  }

  return (
    <section>
      <p className="eyebrow">Quotes</p>
      <h1>Your quotations</h1>
      {msg && <p className="success">{msg}</p>}

      <div className="stack">
        {quotes.map((quote) => (
          <article className="panel quote-card" key={quote.id}>
            <div>
              <span className={`status ${quote.status}`}>{quote.status}</span>
              <h2>{quote.serviceNames.join(' + ')}</h2>
              <p>{quote.description}</p>
              <p className="muted">Estimated duration: {quote.durationHours} hours</p>
            </div>
            <div className="price">£{Number(quote.amount).toFixed(2)}</div>

            {quote.status === 'ready' && (
              <div className="actions">
                <button className="btn" onClick={() => action(quote.id, 'accept')}>Accept quote</button>
                <button className="btn btn-ghost dark" onClick={() => action(quote.id, 'decline')}>Decline</button>
              </div>
            )}
          </article>
        ))}
        {!quotes.length && <div className="panel"><p>No prepared quotes yet.</p></div>}
      </div>

      <h2 className="section-title">Quote requests</h2>
      <div className="stack">
        {requests.map((request) => (
          <article className="panel compact" key={request.id}>
            <span className="status">{request.status}</span>
            <b>{request.serviceNames.join(', ')}</b>
            <span>{new Date(request.createdAt).toLocaleDateString('en-GB')}</span>
          </article>
        ))}
      </div>
    </section>
  );
}
