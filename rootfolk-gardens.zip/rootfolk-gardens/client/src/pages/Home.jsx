import { Link } from 'react-router-dom';
import Nav from '../components/Nav.jsx';

// Reusable page content is stored as arrays so the JSX stays easy to read.
const services = [
  ['01', 'Regular maintenance', 'Reliable visits for lawns, borders, weeding and general garden care.'],
  ['02', 'Hedge cutting & pruning', 'Careful shaping and seasonal pruning for healthy, tidy growth.'],
  ['03', 'Garden tidy-ups', 'One-off help for overgrown spaces, seasonal resets and clearances.'],
  ['04', 'Planting & borders', 'Thoughtful planting and border care to keep your garden full of life.']
];

const steps = [
  ['01', 'Create your account', 'Save your garden details and contact information.'],
  ['02', 'Upload garden photos', 'Send clear photos so Rootfolk can understand the work.'],
  ['03', 'Receive your quote', 'Review a clear quotation based on your garden and request.'],
  ['04', 'Choose an available visit', 'Book a suitable slot and manage it from your dashboard.']
];

export default function Home() {
  return <>
    <Nav />
    <main>
      {/* Hero: editorial layout with a clean garden image rather than the full flyer artwork. */}
      <section className="home-hero">
        <div className="container home-hero-grid">
          <div className="home-hero-copy">
            <p className="eyebrow gold">Natural care for growing spaces</p>
            <h1>Beautiful gardens.<br/><span>Made simple.</span></h1>
            <p className="lead">Professional garden care across Surrey, with clear quotes, flexible visits and an online account that keeps every job easy to manage.</p>

            <div className="actions">
              <Link className="btn" to="/register">Get a free quote <span aria-hidden="true">→</span></Link>
              <a className="text-link" href="#services">Explore services <span aria-hidden="true">↘</span></a>
            </div>

            <div className="hero-proof" aria-label="Rootfolk service benefits">
              <div><strong>Local</strong><span>Surrey based</span></div>
              <div><strong>Flexible</strong><span>One-off or regular</span></div>
              <div><strong>Clear</strong><span>Photo-based quotes</span></div>
            </div>
          </div>

          <div className="hero-visual">
            <div className="hero-photo-frame">
              <img src="/images/rootfolk-hero.jpg" alt="A professionally maintained garden with seating and planted borders" />
            </div>
            <div className="hero-floating-card">
              <span className="mini-mark">R</span>
              <div><b>Friendly local service</b><small>Fully insured & reliable</small></div>
            </div>
            <div className="hero-quote-card">
              <small>Need help with your garden?</small>
              <b>Upload photos. Get a quote.</b>
              <Link to="/register">Start your request →</Link>
            </div>
          </div>
        </div>
      </section>

      {/* Short trust strip gives the page a strong break after the hero. */}
      <section className="trust-band">
        <div className="container trust-band-grid">
          <span>Reliable & professional</span>
          <span>Quality you can see</span>
          <span>Local & trusted</span>
          <span>Flexible garden care</span>
        </div>
      </section>

      <section id="services" className="section container services-section">
        <div className="section-heading">
          <div><p className="eyebrow">Garden care</p><h2>Practical care for gardens that deserve attention.</h2></div>
          <p>From regular maintenance to one-off tidy-ups, Rootfolk keeps outdoor spaces healthy, neat and enjoyable without making the process complicated.</p>
        </div>

        <div className="service-editorial-grid">
          {services.map(([number, title, text]) => (
            <article className="service-editorial-card" key={title}>
              <span>{number}</span>
              <h3>{title}</h3>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section rootfolk-story">
        <div className="container story-grid">
          <div className="story-image-wrap">
            <img src="/images/rootfolk-brand.jpg" alt="Rootfolk Gardens brand artwork" />
          </div>
          <div className="story-copy">
            <p className="eyebrow gold">Why Rootfolk</p>
            <h2>Good garden care should feel straightforward.</h2>
            <p className="lead small">Tell us what you need, show us the garden and choose the visit that works for you. The customer portal keeps quotes, bookings and visit history in one place.</p>
            <div className="story-points">
              <div><b>Photo-based quote requests</b><span>Upload the areas that need attention before a price is prepared.</span></div>
              <div><b>Simple booking management</b><span>Check upcoming work and request a delay, reschedule or cancellation.</span></div>
              <div><b>Visit history</b><span>See when Rootfolk last visited and what work was completed.</span></div>
            </div>
          </div>
        </div>
      </section>

      <section id="process" className="section container process-section">
        <div className="section-heading compact-heading">
          <div><p className="eyebrow">How it works</p><h2>From garden photos to a booked visit.</h2></div>
          <Link className="text-link dark-link" to="/register">Create your account →</Link>
        </div>
        <div className="process-line">
          {steps.map(([number, title, text]) => (
            <div className="process-step" key={title}>
              <span>{number}</span><h3>{title}</h3><p>{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="home-cta">
        <div className="container home-cta-inner">
          <div>
            <p className="eyebrow gold">Rootfolk customer portal</p>
            <h2>Your garden, organised in one place.</h2>
            <p>Request quotes, book available visits, check your last service and manage changes without chasing messages.</p>
          </div>
          <div className="cta-actions">
            <Link className="btn" to="/register">Create an account →</Link>
            <Link className="btn btn-ghost" to="/login">Sign in</Link>
          </div>
        </div>
      </section>
    </main>

    <footer className="footer">
      <div className="container">
        <div className="brand"><span>ROOTFOLK</span><small>GARDENS</small></div>
        <p>Natural care for growing spaces · Surrey</p>
        <p>07960 430982 · rootfolkgardening@gmail.com</p>
      </div>
    </footer>
  </>;
}
