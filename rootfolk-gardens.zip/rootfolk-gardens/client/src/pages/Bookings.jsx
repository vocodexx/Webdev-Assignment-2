import { useEffect, useState } from 'react';
import { api } from '../services/api.js';

export default function Bookings() {
  const [bookings, setBookings] = useState([]);
  const [quotes, setQuotes] = useState([]);
  const [availability, setAvailability] = useState([]);
  const [selectedQuote, setSelectedQuote] = useState('');
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');

  // Refresh bookings, accepted quotes and available diary slots together.
  async function load() {
    const [bookingData, quoteData, availabilityData] = await Promise.all([
      api('/bookings'), api('/quotes'), api('/availability?days=21')
    ]);

    const acceptedQuotes = quoteData.filter((quote) => quote.status === 'accepted');
    setBookings(bookingData);
    setQuotes(acceptedQuotes);
    setAvailability(availabilityData);

    if (!selectedQuote && acceptedQuotes[0]) setSelectedQuote(acceptedQuotes[0].id);
  }

  useEffect(() => { load(); }, []);

  async function book(date, slot) {
    setError('');
    try {
      await api('/bookings', {
        method: 'POST',
        body: JSON.stringify({
          quoteId: selectedQuote,
          date,
          startTime: slot.startTime,
          endTime: slot.endTime
        })
      });
      setMsg('Booking confirmed.');
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  // A change is requested first; the current appointment stays active until admin approval.
  async function requestChange(id, type) {
    const question = type === 'cancellation'
      ? 'Why would you like to cancel?'
      : 'Why would you like to reschedule?';
    const reason = window.prompt(question) || '';

    if (type === 'cancellation') {
      await api(`/bookings/${id}/cancellation-request`, {
        method: 'POST', body: JSON.stringify({ reason })
      });
    } else {
      const requestedDate = window.prompt('Preferred new date (YYYY-MM-DD):') || '';
      const requestedTime = window.prompt('Preferred start time (HH:MM), e.g. 13:30:') || '';
      await api(`/bookings/${id}/reschedule-request`, {
        method: 'POST', body: JSON.stringify({ reason, requestedDate, requestedTime })
      });
    }

    setMsg('Request sent to Rootfolk. Your current booking remains in place until the change is approved.');
    load();
  }

  return (
    <section>
      <p className="eyebrow">Bookings</p>
      <h1>Appointments & availability</h1>
      {msg && <p className="success">{msg}</p>}
      {error && <p className="alert">{error}</p>}

      <h2>Upcoming jobs</h2>
      <div className="stack">
        {bookings.map((booking) => (
          <article className="panel booking" key={booking.id}>
            <div>
              <span className={`status ${booking.status}`}>{booking.status.replaceAll('-', ' ')}</span>
              <h3>{new Date(`${booking.date}T12:00`).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}</h3>
              <p>{booking.startTime}–{booking.endTime} · {booking.serviceNames.join(', ')}</p>
              <p className="price-small">£{Number(booking.amount).toFixed(2)}</p>
            </div>

            {!['cancelled', 'completed'].includes(booking.status) && (
              <div className="actions">
                <button className="btn btn-small" onClick={() => requestChange(booking.id, 'reschedule')}>Request reschedule</button>
                <button className="btn btn-small btn-ghost dark" onClick={() => requestChange(booking.id, 'cancellation')}>Request cancellation</button>
              </div>
            )}
          </article>
        ))}
        {!bookings.length && <div className="panel"><p>No bookings yet.</p></div>}
      </div>

      <div className="panel">
        <h2>Book an accepted quote</h2>
        {quotes.length ? (
          <>
            <label>Quote
              <select value={selectedQuote} onChange={(e) => setSelectedQuote(e.target.value)}>
                {quotes.map((quote) => (
                  <option key={quote.id} value={quote.id}>{quote.serviceNames.join(', ')} — £{quote.amount}</option>
                ))}
              </select>
            </label>

            {/* Each button represents one server-calculated appointment slot. */}
            <div className="availability">
              {availability.map((day) => (
                <div className="day-card" key={day.date}>
                  <b>{new Date(`${day.date}T12:00`).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })}</b>
                  {day.slots.map((slot) => (
                    <button disabled={!slot.available} key={slot.startTime} onClick={() => book(day.date, slot)}>
                      {slot.startTime}<small>{slot.available ? 'Available' : 'Taken'}</small>
                    </button>
                  ))}
                </div>
              ))}
            </div>
          </>
        ) : <p>You need an accepted quote before booking a visit.</p>}
      </div>
    </section>
  );
}
