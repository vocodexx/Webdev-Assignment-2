import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Nav from '../components/Nav.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  // Submit the credentials and send each role to its own dashboard.
  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');

    try {
      const loggedInUser = await login(form.email, form.password);
      navigate(loggedInUser.role === 'admin' ? '/admin' : '/dashboard');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <Nav />
      <main className="auth-page">
        <form className="auth-card" onSubmit={submit}>
          <p className="eyebrow">Welcome back</p>
          <h1>Log in</h1>
          {error && <p className="alert">{error}</p>}

          <label>
            Email
            <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </label>
          <label>
            Password
            <input type="password" required value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </label>

          <button className="btn" disabled={busy}>{busy ? 'Logging in…' : 'Log in'}</button>
          <p className="muted">No account? <Link to="/register">Create one</Link></p>

          {/* Demo accounts make it easy to test both customer and admin views. */}
          <div className="demo-box">
            <b>Demo customer</b><code>customer@rootfolk.test / Garden123!</code>
            <b>Demo admin</b><code>admin@rootfolk.test / RootfolkAdmin1!</code>
          </div>
        </form>
      </main>
    </>
  );
}
