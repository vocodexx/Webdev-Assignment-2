import { useEffect, useState } from 'react';
import Nav from '../components/Nav.jsx';
import { api } from '../services/api.js';

export default function Admin() {
  const [overview, setOverview] = useState({});
  const [requests, setRequests] = useState([]);
  const [changes, setChanges] = useState([]);
  const [msg, setMsg] = useState('');

  // Load summary numbers, quote requests and booking-change requests together.
  async function load() {
    const [overviewData, quoteData, changeData] = await Promise.all([
      api('/admin/overview'),
      api('/admin/quote-requests'),
      api('/admin/change-requests')
    ]);
    setOverview(overviewData);
    setRequests(quoteData);
    setChanges(changeData);
  }

  useEffect(() => { load(); }, []);

  // For this prototype the admin enters a price and duration using prompts.
  async function sendQuote(id) {
    const amount = window.prompt('Quote amount (£):');
    if (!amount) return;
    const durationHours = window.prompt('Estimated duration (hours):', '2') || '2';

    await api(`/admin/quote-requests/${id}/quote`, {
      method: 'POST',
      body: JSON.stringify({ amount, durationHours, validUntil: '2026-12-31' })
    });
    setMsg('Quote sent to customer.');
    load();
  }

  // Admin approval updates the related booking on the server.
  async function resolve(id, action) {
    await api(`/admin/change-requests/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ action })
    });
    setMsg(`Request ${action}d.`);
    load();
  }

  return (
    <>
      <Nav />
      <main className="container admin-page">
        <p className="eyebrow">Rootfolk admin</p>
        <h1>Operations dashboard</h1>
        {msg && <p className="success">{msg}</p>}

        <div className="dashboard-grid four">
          <article className="metric-card"><span>Pending quotes</span><h2>{overview.pendingQuotes || 0}</h2></article>
          <article className="metric-card"><span>Upcoming jobs</span><h2>{overview.upcomingJobs || 0}</h2></article>
          <article className="metric-card"><span>Change requests</span><h2>{overview.changeRequests || 0}</h2></article>
          <article className="metric-card"><span>Customers</span><h2>{overview.customers || 0}</h2></article>
        </div>

        <h2>Quote requests</h2>
        <div className="stack">
          {requests.map((request) => (
            <article className="panel" key={request.id}>
              <span className="status">{request.status}</span>
              <h3>{request.customer?.name || 'Customer'} · {request.serviceNames.join(', ')}</h3>
              <p>{request.description || 'No additional description.'}</p>
              <p className="muted">Garden: {request.garden?.size || '—'} · {request.garden?.condition || '—'} · {request.frequency}</p>

              {/* Only show the garden photos selected for this quote request. */}
              <div className="admin-photos">
                {request.garden?.images
                  ?.filter((img) => request.imageIds.includes(img.id))
                  .map((img) => <img key={img.id} src={img.url} alt={img.originalName} />)}
              </div>

              {request.status === 'under-review' && (
                <button className="btn" onClick={() => sendQuote(request.id)}>Prepare & send quote</button>
              )}
            </article>
          ))}
        </div>

        <h2>Customer change requests</h2>
        <div className="stack">
          {changes.map((change) => (
            <article className="panel compact" key={change.id}>
              <div>
                <span className="status">{change.status}</span>
                <b>{change.customer?.name} · {change.type}</b>
                <span>{change.reason || 'No reason supplied'}</span>
                {change.requestedDate && <span>Requested: {change.requestedDate} {change.requestedTime}</span>}
              </div>

              {change.status === 'pending' && (
                <div className="actions">
                  <button className="btn btn-small" onClick={() => resolve(change.id, 'approve')}>Approve</button>
                  <button className="btn btn-small btn-ghost dark" onClick={() => resolve(change.id, 'decline')}>Decline</button>
                </div>
              )}
            </article>
          ))}
        </div>
      </main>
    </>
  );
}
