import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../services/api.js';

export default function QuoteRequest() {
  const navigate = useNavigate();
  const [services, setServices] = useState([]);
  const [garden, setGarden] = useState(null);
  const [selected, setSelected] = useState([]);
  const [images, setImages] = useState([]);
  const [description, setDescription] = useState('');
  const [frequency, setFrequency] = useState('One-off');
  const [error, setError] = useState('');

  // The service list and customer's garden are both needed on this page.
  useEffect(() => {
    Promise.all([api('/services'), api('/garden')])
      .then(([serviceData, gardenData]) => {
        setServices(serviceData);
        setGarden(gardenData);
      });
  }, []);

  function toggleService(id) {
    setSelected((current) => current.includes(id)
      ? current.filter((value) => value !== id)
      : [...current, id]);
  }

  function toggleImage(id) {
    setImages((current) => current.includes(id)
      ? current.filter((value) => value !== id)
      : [...current, id]);
  }

  async function submit(e) {
    e.preventDefault();
    setError('');
    try {
      await api('/quote-requests', {
        method: 'POST',
        body: JSON.stringify({ serviceIds: selected, description, frequency, imageIds: images })
      });
      navigate('/quotes');
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <section>
      <p className="eyebrow">New quote</p>
      <h1>Tell us what your garden needs.</h1>
      <p className="muted">Choose the work, attach at least two garden photos and Rootfolk can prepare a personalised quotation.</p>
      {error && <p className="alert">{error}</p>}

      <form onSubmit={submit}>
        <div className="panel">
          <h2>1. Choose services</h2>
          <div className="choice-grid">
            {services.map((service) => (
              <button
                type="button"
                className={selected.includes(service.id) ? 'choice active' : 'choice'}
                onClick={() => toggleService(service.id)}
                key={service.id}
              >
                <b>{service.name}</b>
                <span>{service.description}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="panel">
          <h2>2. Job details</h2>
          <label>How often?
            <select value={frequency} onChange={(e) => setFrequency(e.target.value)}>
              <option>One-off</option><option>Weekly</option><option>Fortnightly</option><option>Monthly</option><option>Not sure</option>
            </select>
          </label>
          <label>What would you like us to know?
            <textarea rows="5" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="For example: the rear hedge is very overgrown and the borders need clearing…" />
          </label>
        </div>

        <div className="panel">
          <h2>3. Select garden photos</h2>
          {!garden?.images?.length ? (
            <p>You have no garden photos yet. <Link to="/garden">Upload photos first.</Link></p>
          ) : (
            <div className="photo-grid selectable">
              {garden.images.map((img) => (
                <button
                  type="button"
                  onClick={() => toggleImage(img.id)}
                  className={images.includes(img.id) ? 'photo-select active' : 'photo-select'}
                  key={img.id}
                >
                  <img src={img.url} alt={img.originalName} />
                  <span>{images.includes(img.id) ? '✓ Selected' : 'Select'}</span>
                </button>
              ))}
            </div>
          )}
          <p className="muted">Selected: {images.length} / minimum 2</p>
        </div>

        {/* Button stays disabled until the minimum quote information is supplied. */}
        <button className="btn" disabled={selected.length === 0 || images.length < 2}>Submit quote request</button>
      </form>
    </section>
  );
}
