import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Nav from '../components/Nav.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', phone: '', address: '', postcode: '', password: '' });
  const [error, setError] = useState('');

  // One change handler updates whichever field triggered the event.
  function change(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  async function submit(e) {
    e.preventDefault();
    setError('');
    try {
      await register(form);
      // New customers start by adding information about their garden.
      navigate('/garden');
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <>
      <Nav />
      <main className="auth-page">
        <form className="auth-card wide" onSubmit={submit}>
          <p className="eyebrow">Customer portal</p>
          <h1>Create account</h1>
          <p className="muted">Save your garden, upload photos and manage quotes and visits.</p>
          {error && <p className="alert">{error}</p>}

          <div className="form-grid">
            <label>Full name<input name="name" required onChange={change} /></label>
            <label>Email<input name="email" type="email" required onChange={change} /></label>
            <label>Phone<input name="phone" onChange={change} /></label>
            <label>Postcode<input name="postcode" required onChange={change} /></label>
            <label className="full">Address<input name="address" onChange={change} /></label>
            <label className="full">Password<input name="password" type="password" minLength="8" required onChange={change} /></label>
          </div>

          <button className="btn">Create account</button>
        </form>
      </main>
    </>
  );
}
