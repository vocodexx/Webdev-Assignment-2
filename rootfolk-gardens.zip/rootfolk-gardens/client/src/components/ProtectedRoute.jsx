import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function ProtectedRoute({ children, admin = false }) {
  const { user, loading } = useAuth();

  // Wait until the saved login token has been checked.
  if (loading) return <div className="page-shell"><p>Loading…</p></div>;

  // Visitors must sign in before opening protected pages.
  if (!user) return <Navigate to="/login" replace />;

  // Customer accounts cannot open the admin area.
  if (admin && user.role !== 'admin') return <Navigate to="/dashboard" replace />;

  return children;
}
