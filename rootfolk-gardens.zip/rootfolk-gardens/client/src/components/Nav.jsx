import { Link, NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Nav() {
  const { user, logout } = useAuth();

  return (
    <header className="nav-wrap">
      <nav className="nav container">
        {/* Brand always links back to the public home page. */}
        <Link className="brand" to="/">
          <span>ROOTFOLK</span>
          <small>GARDENS</small>
        </Link>

        <div className="nav-links">
          <a href="/#services">Services</a>
          <a href="/#process">How it works</a>

          {/* Navigation changes depending on the signed-in user's role. */}
          {!user && <NavLink to="/login">Login</NavLink>}
          {!user && <NavLink className="btn btn-small" to="/register">Create account</NavLink>}
          {user?.role === 'customer' && <NavLink to="/dashboard">Dashboard</NavLink>}
          {user?.role === 'admin' && <NavLink to="/admin">Admin</NavLink>}
          {user && <button className="link-button" onClick={logout}>Log out</button>}
        </div>
      </nav>
    </header>
  );
}
