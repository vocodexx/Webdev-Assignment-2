import { NavLink, Outlet } from 'react-router-dom';
import Nav from './Nav.jsx';
import { useAuth } from '../context/AuthContext.jsx';

export default function PortalLayout() {
  const { user } = useAuth();

  return (
    <>
      <Nav />
      <div className="portal container">
        {/* Sidebar gives customers access to each account section. */}
        <aside className="sidebar">
          <p className="eyebrow">Customer portal</p>
          <strong>{user?.name}</strong>
          <NavLink to="/dashboard">Overview</NavLink>
          <NavLink to="/garden">My garden</NavLink>
          <NavLink to="/quote-request">Request a quote</NavLink>
          <NavLink to="/quotes">Quotes</NavLink>
          <NavLink to="/bookings">Bookings</NavLink>
          <NavLink to="/history">Visit history</NavLink>
        </aside>

        {/* Outlet displays the selected customer page. */}
        <main className="portal-main"><Outlet /></main>
      </div>
    </>
  );
}
